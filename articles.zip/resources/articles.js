function getArticles() {
  var articles = [  {"name": "first article","id": "first_article","category": "articles","url": "articles/article_articles.html"},
  {"name": "faq","id": "faq","category": "articles","url": "articles/article_FAQ.html"},
  {"name": "second article","id": "second_article","category": "articles","url": "articles/article_articles2.html"}]
  return articles;
}