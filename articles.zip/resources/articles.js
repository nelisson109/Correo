function getArticles() {
  var articles = [  {"name": "pagina2","id": "pagina2","category": "articles","url": "articles/article_pagina2.html"},
  {"name": "pagina3","id": "pagina3","category": "articles","url": "articles/article_pagina3.html"},
  {"name": "faq","id": "faq","category": "articles","url": "articles/article_FAQ.html"},
  {"name": "pagina1","id": "pagina1","category": "articles","url": "articles/article_pagina1.html"}]
  return articles;
}